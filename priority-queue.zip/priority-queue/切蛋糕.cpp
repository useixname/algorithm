#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn=1e7+10;
int ans=-233333333,n,m,a,sum[maxn];
deque<int>q;
int main()
{
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&a);
        sum[i]=sum[i-1]+a;//ǰ׺��
    }
    q.push_back(0);//����ֵ
    //��sum[j]��С������(j>=i-m&&j<=i-1)
    for(int i=1;i<=n;i++)
    {
        while(q.front()+m<i)
            q.pop_front();//Խ���pop
        ans=fmax(ans,sum[i]-sum[q.front()]);
        while(!q.empty()&&sum[q.back()]>=sum[i])//�ݼ���pop
            q.pop_back();
        q.push_back(i);
    }
    printf("%d\n",ans);
    return 0;
}
